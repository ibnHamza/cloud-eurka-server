package com.example.democloudeurka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCloudEurkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
